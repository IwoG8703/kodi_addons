"""graphql.validation.rules.custom package"""
